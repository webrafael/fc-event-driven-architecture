<?php

namespace Illuminate\Console;

use RuntimeException;

class PromptValidationException extends RuntimeException
{
}
